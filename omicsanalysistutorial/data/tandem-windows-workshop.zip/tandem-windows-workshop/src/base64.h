#ifndef BASE64_H
#define BASE64_H

int b64_decode_mio (char *dest, char *src, size_t size);
#endif /* BASE64_H */
